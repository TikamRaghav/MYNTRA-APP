function    Main(){
    return(
    <div className="body">
    <img src="https://assets.myntassets.com/f_webp,w_980,c_limit,fl_progressive,dpr_2.0/assets/images/2022/7/25/179e278f-77ee-44c2-bf39-9f00b0cd08e01658752429301-Handbags_Desk.jpg" alt="no image" className="myslides" />
   
  </div>
    );
  
}
export default Main;