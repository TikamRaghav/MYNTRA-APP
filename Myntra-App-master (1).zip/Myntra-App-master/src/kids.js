import Kidsbody from "./Kidsbody.js";
import Kidsgrid from "./kidsgrid.js";

function Kidshop(){
    return(
        <div>
            <Kidsbody/>
            <Kidsgrid/>
        </div>
    );
}
export default Kidshop;