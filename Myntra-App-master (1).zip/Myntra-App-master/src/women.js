import Mainwomen from "./mainwomen.js";
import Womengrid from "./womengrid.js";


function Womenshop() {
  return (
    <div>
        <Mainwomen/>
        <Womengrid/>
      
    </div>
  );
}
export default Womenshop;
