
import Main from './body.js';
import Grid from './grid.js';

function Home(){
    return(
        <>
       
        <Main/>
        <Grid/>
        
        </>


    );
}
export default Home;