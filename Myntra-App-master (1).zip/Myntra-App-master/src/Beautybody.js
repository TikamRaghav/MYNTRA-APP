function Beautybody(){
    return(
        <div className="beautybody">
            <div className="h1">
                Home/ <b>Personal Care</b>
            </div>
            <div className="h2">
                <b>Personal Care</b> -96160 items
            </div>
            <div className="filters">
                <div className="heading"><h4>FILTERS</h4></div>
                
                <div className="dropdown">
                    <select name="" id="">
                        <option value="">Bundles</option>
                    </select>
                    <select name="" id="">
                        <option value="">Country of Origin</option>
                    </select>
                    <select name="" id="">
                        <option value="">Size</option>
                    </select>
                </div>
            </div>

        </div>
    )
}
export default Beautybody;