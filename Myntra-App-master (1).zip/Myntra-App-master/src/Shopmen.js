import Mengrid from "./Mengrid.js";
import Menbody from "./Menbody.js";

function Shop(){
    return(
        <>
        <Menbody/>
        <Mengrid/>
       
        </>
    );
}
export default Shop;