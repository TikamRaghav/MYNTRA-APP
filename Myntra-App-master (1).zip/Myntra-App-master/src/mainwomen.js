function Mainwomen(){
    return(
        <>
        <div className="womenbody">
        <img src="https://assets.myntassets.com/f_webp,w_980,c_limit,fl_progressive,dpr_2.0/assets/images/2023/8/30/b9aa3c3d-17a5-4d5e-afed-ba679d629a0d1693375596341-DB.png" alt="" />
        </div>
        </>

    );
}
export default Mainwomen;