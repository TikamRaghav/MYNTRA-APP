import Product from "./Products";
import Beautybody from "./Beautybody";

function Beauty(){
    
    return(
        <div className="beauty">
            <Beautybody/>
            <Product/>
          
        </div>

    );
}
export default Beauty;